package com.glassbuds.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glassbuds.app.Kind
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.roundToInt

val Violet = Color(0xFF8B5CFF)
val Cyan = Color(0xFF22E4FF)
val Pink = Color(0xFFFF5CAA)
val Mint = Color(0xFF3CF2B0)
val TextHi = Color(0xFFF4F2FF)
val TextLo = Color(0xFFA9A4C8)

@Composable
fun GlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, secondary = Cyan,
            background = Color(0xFF0A0817), surface = Color(0xFF14102B),
            onSurface = TextHi, onBackground = TextHi
        ),
        content = content
    )
}

/** Efecto cristal: relleno translúcido con degradado y borde de luz. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(28.dp), strength: Float = 0.10f): Modifier = this
    .clip(shape)
    .background(
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = strength + 0.06f), Color.White.copy(alpha = strength * 0.35f))
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(Color.White.copy(0.5f), Color.White.copy(0.06f), Color.White.copy(0.22f))
        ),
        shape
    )

@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0820), Color(0xFF150C33), Color(0xFF07182B))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            fun blob(c: Color, cx: Float, cy: Float, r: Float) {
                drawCircle(
                    Brush.radialGradient(listOf(c.copy(alpha = 0.5f), Color.Transparent), center = Offset(cx, cy), radius = r),
                    radius = r, center = Offset(cx, cy)
                )
            }
            blob(Violet, w * 0.05f, h * 0.08f, w * 0.95f)
            blob(Cyan, w * 1.0f, h * 0.45f, w * 0.8f)
            blob(Pink, w * 0.2f, h * 0.95f, w * 0.9f)
        }
        content()
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.glass(RoundedCornerShape(50), 0.06f).padding(4.dp)) {
        options.forEachIndexed { i, t ->
            val sel = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (sel) Brush.linearGradient(listOf(Violet, Cyan))
                        else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .clickable { onSelect(i) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(t, color = if (sel) Color.White else TextLo, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
    }
}

private fun valueAt(y: Float, h: Float, inset: Float, lo: Float, hi: Float): Float {
    val f = 1f - ((y - inset) / (h - 2 * inset)).coerceIn(0f, 1f)
    val v = lo + (hi - lo) * f
    return (v * 2).roundToInt() / 2f
}

/** Slider vertical de ecualizador con acabado cristal. */
@Composable
fun VSlider(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier, lo: Float = -12f, hi: Float = 12f) {
    val cur by rememberUpdatedState(onChange)
    Canvas(
        modifier
            .pointerInput(Unit) {
                val inset = 12.dp.toPx()
                detectVerticalDragGestures { change, _ ->
                    change.consume()
                    cur(valueAt(change.position.y, size.height.toFloat(), inset, lo, hi))
                }
            }
            .pointerInput(Unit) {
                val inset = 12.dp.toPx()
                detectTapGestures { cur(valueAt(it.y, size.height.toFloat(), inset, lo, hi)) }
            }
    ) {
        val inset = 12.dp.toPx()
        val cx = size.width / 2
        val trackW = 6.dp.toPx()
        drawRoundRect(
            Color.White.copy(alpha = 0.14f),
            Offset(cx - trackW / 2, inset), Size(trackW, size.height - 2 * inset),
            CornerRadius(trackW)
        )
        val f = (value - lo) / (hi - lo)
        val y = inset + (1f - f) * (size.height - 2 * inset)
        val y0 = size.height / 2
        val top = minOf(y, y0)
        val hh = kotlin.math.abs(y - y0)
        drawRoundRect(
            Brush.verticalGradient(listOf(Cyan, Violet), startY = inset, endY = size.height - inset),
            Offset(cx - trackW / 2, top), Size(trackW, hh.coerceAtLeast(2f)),
            CornerRadius(trackW)
        )
        drawCircle(Cyan.copy(alpha = 0.35f), 16.dp.toPx(), Offset(cx, y))
        drawCircle(Color.White, 9.dp.toPx(), Offset(cx, y))
    }
}

/** Dial circular de volumen (arco de 270°). */
@Composable
fun VolumeDial(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val cur by rememberUpdatedState(onChange)
    fun fracAt(p: Offset, w: Float, h: Float): Float {
        val dx = p.x - w / 2
        val dy = p.y - h / 2
        val a = (atan2(dy, dx) * 180f / PI.toFloat() + 360f) % 360f
        val rel = (a - 135f + 360f) % 360f
        return if (rel > 270f) (if (rel < 315f) 1f else 0f) else rel / 270f
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        cur(fracAt(change.position, size.width.toFloat(), size.height.toFloat()))
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { cur(fracAt(it, size.width.toFloat(), size.height.toFloat())) }
                }
        ) {
            val stroke = 22.dp.toPx()
            val d = size.minDimension - stroke
            val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
            drawArc(Color.White.copy(0.12f), 135f, 270f, false, tl, Size(d, d), style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(
                Brush.sweepGradient(listOf(Cyan, Violet, Pink, Cyan), center = center),
                135f, 270f * value.coerceIn(0f, 1f), false, tl, Size(d, d),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            val ang = (135f + 270f * value.coerceIn(0f, 1f)) * PI.toFloat() / 180f
            val r = d / 2
            val knob = Offset(center.x + r * kotlin.math.cos(ang), center.y + r * kotlin.math.sin(ang))
            drawCircle(Color.White.copy(0.35f), 17.dp.toPx(), knob)
            drawCircle(Color.White, 10.dp.toPx(), knob)
        }
        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${(value * 100).roundToInt()}%", color = TextHi, fontSize = 44.sp, fontWeight = FontWeight.Bold)
            Text("Volumen", color = TextLo, fontSize = 14.sp)
        }
    }
}

/** Ilustración vectorial del tipo de dispositivo. */
@Composable
fun DeviceArt(kind: Kind, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawCircle(
            Brush.radialGradient(listOf(Cyan.copy(0.35f), Color.Transparent), center = center, radius = w * 0.55f),
            radius = w * 0.55f
        )
        val metal = Brush.linearGradient(listOf(Color(0xFFF1EEFF), Color(0xFF8E86C4)))
        when (kind) {
            Kind.BUDS -> {
                drawRoundRect(
                    Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x11FFFFFF))),
                    Offset(w * .16f, h * .36f), Size(w * .68f, h * .36f), CornerRadius(h * .18f)
                )
                for (dx in listOf(.34f, .66f)) {
                    drawCircle(metal, h * .1f, Offset(w * dx, h * .5f))
                    drawRoundRect(metal, Offset(w * dx - h * .028f, h * .5f), Size(h * .056f, h * .18f), CornerRadius(h * .028f))
                }
            }
            Kind.SPEAKER -> {
                drawRoundRect(metal, Offset(w * .3f, h * .18f), Size(w * .4f, h * .64f), CornerRadius(w * .12f))
                drawCircle(Color(0xFF1B1538), w * .11f, Offset(w * .5f, h * .6f))
                drawCircle(Color(0xFF1B1538), w * .045f, Offset(w * .5f, h * .33f))
            }
            Kind.HEADPHONES -> {
                drawArc(
                    metal, 180f, 180f, false, Offset(w * .2f, h * .12f), Size(w * .6f, h * .62f),
                    style = Stroke(h * .07f, cap = StrokeCap.Round)
                )
                drawRoundRect(metal, Offset(w * .12f, h * .48f), Size(w * .2f, h * .32f), CornerRadius(h * .09f))
                drawRoundRect(metal, Offset(w * .68f, h * .48f), Size(w * .2f, h * .32f), CornerRadius(h * .09f))
            }
        }
    }
}
