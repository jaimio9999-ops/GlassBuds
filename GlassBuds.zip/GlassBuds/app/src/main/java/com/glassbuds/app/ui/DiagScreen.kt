package com.glassbuds.app.ui

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.glassbuds.app.GlassVM

private fun granted(ctx: Context, p: String) =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

private fun report(ctx: Context, vm: GlassVM): List<Triple<String, String, Boolean>> {
    val pm = ctx.packageManager
    val fx = vm.fx
    val out = mutableListOf<Triple<String, String, Boolean>>()
    out += Triple("Teléfono", "${Build.MANUFACTURER} ${Build.MODEL}", true)
    out += Triple("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", Build.VERSION.SDK_INT >= 23)
    out += Triple("Bluetooth", if (!vm.bt.supported) "No tiene" else if (vm.bt.btOn) "Encendido" else "Apagado", vm.bt.supported && vm.bt.btOn)
    out += Triple("Bluetooth LE", if (pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) "Sí" else "No", true)
    val btPerm = if (Build.VERSION.SDK_INT >= 31)
        granted(ctx, Manifest.permission.BLUETOOTH_CONNECT) && granted(ctx, Manifest.permission.BLUETOOTH_SCAN)
    else granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
    out += Triple("Permiso de búsqueda Bluetooth", if (btPerm) "Concedido" else "Falta", btPerm)
    if (Build.VERSION.SDK_INT < 31) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        val on = LocationManagerCompat.isLocationEnabled(lm)
        out += Triple("Ubicación (necesaria para buscar)", if (on) "Activada" else "Apagada", on)
    }
    val mic = granted(ctx, Manifest.permission.RECORD_AUDIO)
    out += Triple("Micrófono (modo ambiente)", if (mic) "Concedido" else "Falta", mic)
    out += Triple("Ecualizador del sistema", fx.eqInfo, fx.hwOk)
    out += Triple("Reproductores enganchados", "${fx.sessions}", fx.hwOk || fx.sessions > 0)
    out += Triple("Refuerzo de graves", if (fx.bbOk) "Compatible" else "No compatible", fx.bbOk)
    out += Triple("Sonido espacial", if (fx.vrOk) "Compatible" else "No compatible", fx.vrOk)
    out += Triple("Volumen extra", if (fx.ldOk) "Compatible" else "No compatible", fx.ldOk)
    val pw = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val ignoring = pw.isIgnoringBatteryOptimizations(ctx.packageName)
    out += Triple("Sin restricción de batería", if (ignoring) "Sí" else "No (puede cerrarse en segundo plano)", ignoring)
    return out
}

@Composable
fun DiagScreen(vm: GlassVM) {
    val ctx = LocalContext.current
    val rows = report(ctx, vm)
    val oem = Build.MANUFACTURER.lowercase()
    val tip = when {
        oem in listOf("infinix", "tecno", "itel") ->
            "HiOS/XOS: en Ajustes > Batería (o Phone Master) permite que GlassBuds funcione en segundo plano y ánclala en Recientes."
        oem in listOf("xiaomi", "redmi", "poco") ->
            "MIUI/HyperOS: activa Inicio automático y pon el ahorro de batería en “Sin restricciones”."
        oem in listOf("oppo", "realme", "oneplus", "vivo", "iqoo") ->
            "ColorOS/OriginOS: permite Inicio automático y actividad en segundo plano para GlassBuds."
        oem == "samsung" -> "One UI: quita GlassBuds de las “Apps en suspensión” en Cuidado del dispositivo > Batería."
        oem == "huawei" || oem == "honor" -> "Gestiona la app manualmente en Inicio de aplicaciones y permite ejecución en segundo plano."
        else -> "Si el ecualizador se detiene al cerrar la app, quita la restricción de batería de GlassBuds."
    }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(20.dp, 12.dp, 20.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Diagnóstico", color = TextHi, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Así se adapta GlassBuds a tu teléfono", color = TextLo, fontSize = 14.sp)
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), 0.09f).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            rows.forEach { (k, v, ok) ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(k, color = TextLo, fontSize = 12.sp)
                        Text(v, color = TextHi, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(if (ok) Mint else Pink)
                            .padding(horizontal = 8.dp, vertical = 8.dp)
                    )
                }
            }
        }
        Text(tip, color = TextLo, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.weight(1f).glass(RoundedCornerShape(20.dp), 0.08f)
                    .clickable { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) { Text("BATERÍA", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(Violet, Cyan)))
                    .clickable {
                        val text = rows.joinToString("\n") { "${it.first}: ${it.second}" }
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                        ctx.startActivity(Intent.createChooser(send, "Compartir diagnóstico"))
                    }
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) { Text("COMPARTIR", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
    }
}
