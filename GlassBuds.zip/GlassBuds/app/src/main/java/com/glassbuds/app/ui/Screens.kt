package com.glassbuds.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothConnected
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.glassbuds.app.BtDev
import com.glassbuds.app.GlassVM
import com.glassbuds.app.Kind

@Composable
private fun Pill(text: String, icon: ImageVector, tint: Color = Cyan) {
    Row(
        Modifier.glass(RoundedCornerShape(50), 0.07f).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, color = TextHi, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Title(title: String, sub: String, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextHi, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = TextLo, fontSize = 14.sp)
        }
        trailing()
    }
}

@Composable
private fun RoundBtn(icon: ImageVector, onClick: () -> Unit, active: Boolean = false) {
    Box(
        Modifier
            .size(46.dp)
            .glass(CircleShape, if (active) 0.2f else 0.08f)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = if (active) Cyan else TextHi) }
}

private fun micGranted(ctx: android.content.Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

@Composable
fun HomeScreen(vm: GlassVM) {
    val bt = vm.bt
    val fx = vm.fx
    val ctx = LocalContext.current
    val sel: BtDev? = bt.devices.firstOrNull { it.address == vm.selected }
        ?: bt.devices.firstOrNull { it.connected }

    LazyColumn(
        contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Title("Mis dispositivos", if (bt.btOn) "Audífonos Bluetooth" else "Bluetooth apagado") {
                RoundBtn(Icons.Rounded.Refresh, { bt.refresh() })
                Spacer(Modifier.width(10.dp))
                RoundBtn(Icons.Rounded.Bluetooth, { vm.askPerms(); bt.scan() }, active = bt.scanning)
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(36.dp), 0.09f).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                DeviceArt(sel?.kind ?: Kind.HEADPHONES, Modifier.fillMaxWidth().height(190.dp))
                Spacer(Modifier.height(8.dp))
                Text(sel?.name ?: "Sin dispositivo", color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (sel?.connected == true) Pill("Conectado", Icons.Rounded.BluetoothConnected)
                    else Pill(if (sel == null) "Busca o conecta uno" else "Desconectado", Icons.Rounded.Bluetooth, TextLo)
                    Pill(if ((sel?.battery ?: -1) >= 0) "${sel!!.battery}%" else "Batería —", Icons.Rounded.BatteryFull, Mint)
                }
                Spacer(Modifier.height(18.dp))
                Segmented(
                    listOf("ANC", "Ambiente", "OFF"), fx.anc,
                    { m ->
                        if (m == 1 && !micGranted(ctx)) vm.askPerms()
                        fx.setAnc(m, micGranted(ctx))
                    },
                    Modifier.fillMaxWidth()
                )
                if (fx.ancNote.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(fx.ancNote, color = TextLo, fontSize = 12.sp)
                }
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp), 0.07f)
                        .clickable { vm.tab = 1 }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Equalizer, null, tint = Violet)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Ecualizador", color = TextHi, fontWeight = FontWeight.SemiBold)
                        Text(fx.preset, color = TextLo, fontSize = 13.sp)
                    }
                    Text("›", color = TextLo, fontSize = 22.sp)
                }
            }
        }
        item { Text("Dispositivos", color = TextLo, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        items(bt.devices, key = { it.address }) { d ->
            Row(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp), 0.07f)
                    .clickable {
                        vm.selected = d.address
                        if (!d.bonded) bt.pair(d.address)
                        else if (!d.connected) ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(52.dp).glass(CircleShape, 0.1f),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Headphones, null, tint = if (d.connected) Cyan else TextLo) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.name, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(
                        when {
                            d.connected -> "Conectado" + if (d.battery >= 0) " • ${d.battery}%" else ""
                            d.bonded -> "Vinculado • toca para conectar"
                            else -> "Cercano • toca para vincular"
                        },
                        color = if (d.connected) Mint else TextLo, fontSize = 13.sp
                    )
                }
                if (!d.bonded) Icon(Icons.Rounded.Add, null, tint = Cyan)
            }
        }
        item {
            if (bt.devices.isEmpty()) {
                Column(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp), 0.06f).padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        if (!bt.supported) "Este teléfono no tiene Bluetooth"
                        else if (!bt.btOn) "Enciende el Bluetooth para ver tus audífonos"
                        else if (bt.scanning) "Buscando audífonos cercanos…"
                        else "No hay audífonos todavía. Ponlos en modo emparejamiento y pulsa el botón Bluetooth de arriba.",
                        color = TextLo, fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun EqScreen(vm: GlassVM) {
    val fx = vm.fx
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(20.dp, 12.dp, 20.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Title("Ecualizador", "10 bandas • ±12 dB") {
            Switch(
                checked = fx.eqOn, onCheckedChange = { fx.eqOn = it; fx.applyAll() },
                colors = SwitchDefaults.colors(checkedTrackColor = Cyan, checkedThumbColor = Color.White)
            )
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(fx.presets.keys.toList()) { name ->
                val on = fx.preset == name
                Text(
                    name,
                    color = if (on) Color.White else TextLo,
                    fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .glass(RoundedCornerShape(50), if (on) 0.28f else 0.07f)
                        .clickable { fx.setPreset(name) }
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
        }
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp), 0.09f).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("+12 dB", color = TextLo, fontSize = 11.sp)
                Text(fx.preset, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Row(Modifier.fillMaxWidth()) {
                for (i in 0 until 10) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        VSlider(
                            fx.gains[i], { fx.setGain(i, it) },
                            Modifier.fillMaxWidth().height(230.dp)
                        )
                        Text(fx.labels[i], color = TextLo, fontSize = 10.sp)
                        Text("%.0f".format(fx.gains[i]), color = TextHi, fontSize = 10.sp)
                    }
                }
            }
            Text("−12 dB • Hz", color = TextLo, fontSize = 11.sp)
        }
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), 0.08f).padding(18.dp)) {
            Text("Graves", color = TextHi, fontWeight = FontWeight.SemiBold)
            Slider(
                value = fx.bass, onValueChange = { fx.setBassTone(it) }, valueRange = -9f..9f,
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan, inactiveTrackColor = Color.White.copy(0.15f))
            )
            Text("Agudos", color = TextHi, fontWeight = FontWeight.SemiBold)
            Slider(
                value = fx.treble, onValueChange = { fx.setTrebleTone(it) }, valueRange = -9f..9f,
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Violet, inactiveTrackColor = Color.White.copy(0.15f))
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.weight(1f).glass(RoundedCornerShape(20.dp), 0.08f).clickable { fx.reset() }.padding(16.dp),
                contentAlignment = Alignment.Center
            ) { Text("RESTABLECER", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(Violet, Cyan)))
                    .clickable { fx.applyAll() }.padding(16.dp),
                contentAlignment = Alignment.Center
            ) { Text("GUARDAR", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
        if (!fx.hwOk) {
            Text(
                "Tu teléfono no aplica el ecualizador global. Abre tu app de música (Spotify, YouTube Music…): GlassBuds se engancha a ella automáticamente.",
                color = Pink, fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.07f).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextHi, fontWeight = FontWeight.SemiBold)
            Text(sub, color = TextLo, fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Mint, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun SoundScreen(vm: GlassVM) {
    val fx = vm.fx
    val ctx = LocalContext.current
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(20.dp, 12.dp, 20.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Title("Sonido", "Cancelación y control de audio")
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp), 0.09f).padding(18.dp)) {
            Text("Cancelación de ruido", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Spacer(Modifier.height(12.dp))
            Segmented(
                listOf("ANC", "Ambiente", "OFF"), fx.anc,
                { m ->
                    if (m == 1 && !micGranted(ctx)) vm.askPerms()
                    fx.setAnc(m, micGranted(ctx))
                },
                Modifier.fillMaxWidth()
            )
            if (fx.ancNote.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(fx.ancNote, color = TextLo, fontSize = 12.sp)
            }
        }
        VolumeDial(
            fx.volume, { fx.setVolume(it) },
            Modifier.fillMaxWidth().height(280.dp).glass(RoundedCornerShape(36.dp), 0.08f).padding(24.dp)
        )
        ToggleRow("Refuerzo de graves", "Bass boost del sistema", fx.bassBoostOn) { fx.bassBoostOn = it; fx.applyAll() }
        ToggleRow("Sonido espacial", "Virtualizador estéreo", fx.spatialOn) { fx.spatialOn = it; fx.applyAll() }
        ToggleRow("Volumen extra", "Aumenta la ganancia de salida", fx.loudOn) { fx.loudOn = it; fx.applyAll() }
    }
}

@Composable
fun NavBar(vm: GlassVM, modifier: Modifier = Modifier) {
    val items = listOf(
        Icons.Rounded.Headphones to "Dispositivos",
        Icons.Rounded.Equalizer to "Ecualizador",
        Icons.Rounded.Tune to "Sonido",
        Icons.Rounded.Info to "Diagnóstico"
    )
    Row(
        modifier.glass(RoundedCornerShape(36.dp), 0.12f).padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items.forEachIndexed { i, (ic, label) ->
            val on = vm.tab == i
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (on) Brush.linearGradient(listOf(Violet, Cyan))
                        else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .clickable { vm.tab = i }
                    .padding(horizontal = if (on) 18.dp else 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(ic, null, tint = if (on) Color.White else TextLo, modifier = Modifier.size(22.dp))
                if (on) {
                    Spacer(Modifier.width(8.dp))
                    Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
            }
        }
    }
}
