package com.glassbuds.app

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import kotlin.math.abs
import kotlin.math.ln

class GlassApp : Application() {
    val fx by lazy { AudioFx(this) }
}

enum class Kind { HEADPHONES, BUDS, SPEAKER }

data class BtDev(
    val name: String,
    val address: String,
    val connected: Boolean,
    val bonded: Boolean,
    val battery: Int,
    val kind: Kind
)

class GlassVM(app: Application) : AndroidViewModel(app) {
    val bt = BtController(app)
    val fx = (app as GlassApp).fx
    var tab by mutableIntStateOf(0)
    var selected by mutableStateOf<String?>(null)
    var askPerms: () -> Unit = {}

    init { bt.start() }

    override fun onCleared() { bt.stop() }
}

/** Detección de audífonos Bluetooth (vinculados, conectados y cercanos). */
class BtController(private val ctx: Context) {
    val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    val devices = mutableStateListOf<BtDev>()
    var scanning by mutableStateOf(false)
    var btOn by mutableStateOf(false)
    val supported = adapter != null

    private val found = LinkedHashMap<String, BluetoothDevice>()
    private val connectedAddr = HashSet<String>()
    private val battery = HashMap<String, Int>()
    private var registered = false

    private val ACTION_BATT = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
    private val EXTRA_BATT = "android.bluetooth.device.extra.BATTERY_LEVEL"
    private val ACTION_VENDOR = "android.bluetooth.headset.action.VENDOR_SPECIFIC_HEADSET_EVENT"
    private val CAT_APPLE = "android.bluetooth.headset.intent.category.companyid.76"
    private val EXTRA_CMD = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_CMD"
    private val EXTRA_ARGS = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_ARGS"

    private fun deviceOf(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(c: Context, i: Intent) {
            val d = deviceOf(i)
            try {
                when (i.action) {
                    BluetoothDevice.ACTION_FOUND -> d?.let { found[it.address] = it; rebuild() }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> scanning = false
                    BluetoothAdapter.ACTION_STATE_CHANGED -> refresh()
                    BluetoothDevice.ACTION_ACL_CONNECTED,
                    BluetoothDevice.ACTION_ACL_DISCONNECTED,
                    BluetoothDevice.ACTION_BOND_STATE_CHANGED -> refresh()
                    ACTION_BATT -> d?.let {
                        val l = i.getIntExtra(EXTRA_BATT, -1)
                        if (l in 0..100) { battery[it.address] = l; rebuild() }
                    }
                }
            } catch (_: SecurityException) {
            }
        }
    }

    /** Batería reportada por los audífonos vía comando HFP (+IPHONEACCEV), muy común en TWS. */
    private val vendorReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(c: Context, i: Intent) {
            try {
                val d = deviceOf(i) ?: return
                if (i.getStringExtra(EXTRA_CMD) != "+IPHONEACCEV") return
                @Suppress("DEPRECATION")
                val raw = i.getSerializableExtra(EXTRA_ARGS) as? Array<*> ?: return
                val a = raw.map { (it as? Int) ?: it?.toString()?.toIntOrNull() ?: -1 }
                var k = 1
                while (k + 1 < a.size) {
                    if (a[k] == 1 && a[k + 1] in 0..9) {
                        battery[d.address] = (a[k + 1] + 1) * 10
                        rebuild()
                    }
                    k += 2
                }
            } catch (_: Throwable) {
            }
        }
    }

    fun start() {
        if (registered) return
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            addAction(ACTION_BATT)
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        val v = IntentFilter(ACTION_VENDOR).apply { addCategory(CAT_APPLE) }
        ContextCompat.registerReceiver(ctx, vendorReceiver, v, ContextCompat.RECEIVER_EXPORTED)
        registered = true
        refresh()
    }

    fun stop() {
        if (registered) {
            try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
            try { ctx.unregisterReceiver(vendorReceiver) } catch (_: Exception) {}
        }
        registered = false
    }

    @SuppressLint("MissingPermission")
    fun refresh() {
        val ad = adapter ?: return
        try {
            btOn = ad.isEnabled
            connectedAddr.clear()
            ad.bondedDevices?.forEach { found.putIfAbsent(it.address, it) }
            for (p in intArrayOf(BluetoothProfile.A2DP, BluetoothProfile.HEADSET)) {
                ad.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
                    override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                        try {
                            proxy.connectedDevices.forEach {
                                connectedAddr.add(it.address); found[it.address] = it
                            }
                        } catch (_: SecurityException) {
                        }
                        try { ad.closeProfileProxy(profile, proxy) } catch (_: Exception) {}
                        rebuild()
                    }
                    override fun onServiceDisconnected(profile: Int) {}
                }, p)
            }
            rebuild()
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    fun scan() {
        val ad = adapter ?: return
        try {
            if (ad.isDiscovering) ad.cancelDiscovery()
            scanning = ad.startDiscovery()
        } catch (_: SecurityException) {
            scanning = false
        }
    }

    @SuppressLint("MissingPermission")
    fun pair(address: String) {
        try { found[address]?.createBond() } catch (_: SecurityException) {}
    }

    @SuppressLint("MissingPermission")
    private fun rebuild() {
        val list = found.values.mapNotNull { d ->
            try {
                val cls = d.bluetoothClass
                if (cls != null && cls.majorDeviceClass != BluetoothClass.Device.Major.AUDIO_VIDEO) return@mapNotNull null
                val name = (try { d.name } catch (_: SecurityException) { null }) ?: return@mapNotNull null
                BtDev(
                    name = name,
                    address = d.address,
                    connected = d.address in connectedAddr,
                    bonded = d.bondState == BluetoothDevice.BOND_BONDED,
                    battery = battery[d.address] ?: readBattery(d),
                    kind = kindOf(name, cls)
                )
            } catch (_: SecurityException) { null }
        }.sortedWith(compareByDescending<BtDev> { it.connected }.thenByDescending { it.bonded })
        devices.clear()
        devices.addAll(list)
    }

    private fun readBattery(d: BluetoothDevice): Int = try {
        val v = d.javaClass.getMethod("getBatteryLevel").invoke(d) as Int
        if (v in 0..100) v else -1
    } catch (_: Throwable) { -1 }

    private fun kindOf(name: String, c: BluetoothClass?): Kind {
        val n = name.lowercase()
        return when (c?.deviceClass) {
            BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES -> Kind.HEADPHONES
            BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET,
            BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE -> Kind.BUDS
            BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER,
            BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO -> Kind.SPEAKER
            else -> when {
                listOf("buds", "pods", "tws", "ear", "air", "free").any { n.contains(it) } -> Kind.BUDS
                listOf("speaker", "box", "flip", "charge", "go ").any { n.contains(it) } -> Kind.SPEAKER
                else -> Kind.HEADPHONES
            }
        }
    }
}

/** Cadena de efectos (EQ, graves, espacial, volumen) enganchada a una sesión de audio. */
class FxChain(private val session: Int) {
    private var eq: Equalizer? = null
    private var bb: BassBoost? = null
    private var vr: Virtualizer? = null
    private var ld: LoudnessEnhancer? = null
    var eqOk = false
    var bbOk = false
    var vrOk = false
    var ldOk = false
    var info = ""

    fun apply(fx: AudioFx) {
        try {
            if (eq == null) eq = Equalizer(0, session)
            val e = eq!!
            e.enabled = fx.eqOn
            val n = e.numberOfBands.toInt()
            val range = e.bandLevelRange
            val lo = range[0].toInt()
            val hi = range[1].toInt()
            val sum = FloatArray(n)
            val cnt = IntArray(n)
            for (i in 0 until 10) {
                var best = 0
                var bd = Float.MAX_VALUE
                for (b in 0 until n) {
                    val c = e.getCenterFreq(b.toShort()) / 1000f
                    val d = abs(ln(fx.freqs[i] / c))
                    if (d < bd) { bd = d; best = b }
                }
                sum[best] += fx.effective(i); cnt[best]++
            }
            for (b in 0 until n) {
                val db = if (cnt[b] > 0) sum[b] / cnt[b] else 0f
                e.setBandLevel(b.toShort(), (db * 100).toInt().coerceIn(lo, hi).toShort())
            }
            info = "$n bandas del sistema, ${lo / 100}…${hi / 100} dB"
            eqOk = true
        } catch (_: Throwable) {
            eqOk = false
        }
        try {
            if (bb == null) bb = BassBoost(0, session)
            bb!!.enabled = fx.bassBoostOn
            if (fx.bassBoostOn && bb!!.strengthSupported) bb!!.setStrength(800)
            bbOk = true
        } catch (_: Throwable) { bbOk = false }
        try {
            if (vr == null) vr = Virtualizer(0, session)
            vr!!.enabled = fx.spatialOn
            if (fx.spatialOn && vr!!.strengthSupported) vr!!.setStrength(800)
            vrOk = true
        } catch (_: Throwable) { vrOk = false }
        try {
            if (ld == null) ld = LoudnessEnhancer(session)
            ld!!.enabled = fx.loudOn
            if (fx.loudOn) ld!!.setTargetGain(600)
            ldOk = true
        } catch (_: Throwable) { ldOk = false }
    }

    fun release() {
        listOf<AudioEffect?>(eq, bb, vr, ld).forEach { try { it?.release() } catch (_: Throwable) {} }
        eq = null; bb = null; vr = null; ld = null
    }
}

/**
 * Ecualizador de 10 bandas + efectos. Se engancha a la sesión global (0) y, además,
 * a cada reproductor que anuncie su sesión de audio (Spotify, YouTube Music, etc.),
 * lo que lo hace compatible con teléfonos que ignoran la sesión global.
 */
class AudioFx(private val app: Application) {
    private val prefs = app.getSharedPreferences("fx", Context.MODE_PRIVATE)
    private val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    val freqs = floatArrayOf(31.5f, 63f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
    val labels = listOf("31", "63", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

    val presets: LinkedHashMap<String, List<Float>> = linkedMapOf(
        "Plano" to listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Acústico" to listOf(4f, 3.5f, 3f, 1.5f, 2f, 2f, 3f, 3.5f, 3f, 2f),
        "Bass Booster" to listOf(7f, 6f, 5f, 3f, 1f, 0f, 0f, 0f, 0f, 0f),
        "Bass Reducer" to listOf(-6f, -5f, -4f, -2f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Rock" to listOf(5f, 4f, 3f, 1f, -1f, -1f, 1f, 3f, 4f, 5f),
        "Pop" to listOf(-1f, 1f, 3f, 4f, 3f, 1f, -1f, -1f, 1f, 2f),
        "Voces" to listOf(-3f, -3f, -2f, 1f, 4f, 5f, 4f, 2f, 0f, -1f),
        "Electrónica" to listOf(6f, 5f, 2f, 0f, -2f, 2f, 1f, 3f, 5f, 6f),
        "Clásica" to listOf(0f, 0f, 0f, 0f, 0f, 0f, -2f, -3f, -3f, -5f)
    )

    var eqOn by mutableStateOf(prefs.getBoolean("eqOn", true))
    val gains = mutableStateListOf<Float>().apply {
        val saved = prefs.getString("gains", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
        if (saved != null && saved.size == 10) addAll(saved) else addAll(List(10) { 0f })
    }
    var bass by mutableFloatStateOf(prefs.getFloat("bass", 0f))
    var treble by mutableFloatStateOf(prefs.getFloat("treble", 0f))
    var preset by mutableStateOf(prefs.getString("preset", "Plano") ?: "Plano")
    var bassBoostOn by mutableStateOf(prefs.getBoolean("bb", false))
    var spatialOn by mutableStateOf(prefs.getBoolean("sp", false))
    var loudOn by mutableStateOf(prefs.getBoolean("ld", false))
    var anc by mutableIntStateOf(2) // 0 = ANC, 1 = Ambiente, 2 = Apagado
    var ancNote by mutableStateOf("")
    var volume by mutableFloatStateOf(0f)

    // Estado de compatibilidad (para pantalla de diagnóstico)
    var hwOk by mutableStateOf(true)
    var eqInfo by mutableStateOf("—")
    var bbOk by mutableStateOf(false)
    var vrOk by mutableStateOf(false)
    var ldOk by mutableStateOf(false)
    var sessions by mutableIntStateOf(0)

    private val chains = HashMap<Int, FxChain>()
    private val ambient = Ambient()

    private val sessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val s = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (s <= 0) return
            when (i.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    if (!chains.containsKey(s)) chains[s] = FxChain(s)
                    applyAll()
                }
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    chains.remove(s)?.release()
                    applyAll()
                }
            }
        }
    }

    init {
        chains[0] = FxChain(0)
        try {
            val f = IntentFilter().apply {
                addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
            }
            ContextCompat.registerReceiver(app, sessionReceiver, f, ContextCompat.RECEIVER_EXPORTED)
        } catch (_: Throwable) {
        }
        readVolume()
        applyAll()
    }

    fun setPreset(name: String) {
        presets[name]?.let { p -> p.forEachIndexed { i, v -> gains[i] = v } }
        bass = 0f; treble = 0f
        preset = name
        applyAll()
    }

    fun setGain(i: Int, v: Float) { gains[i] = v; preset = "Personalizado"; applyAll() }
    fun setBassTone(v: Float) { bass = v; preset = "Personalizado"; applyAll() }
    fun setTrebleTone(v: Float) { treble = v; preset = "Personalizado"; applyAll() }
    fun reset() = setPreset("Plano")

    fun effective(i: Int): Float {
        var g = gains[i]
        if (i <= 2) g += bass
        if (i >= 6) g += treble
        return g.coerceIn(-12f, 12f)
    }

    fun applyAll() {
        chains.values.forEach { it.apply(this) }
        val ok = chains.values.firstOrNull { it.eqOk }
        hwOk = ok != null
        eqInfo = ok?.info ?: "No disponible en la sesión global"
        bbOk = chains.values.any { it.bbOk }
        vrOk = chains.values.any { it.vrOk }
        ldOk = chains.values.any { it.ldOk }
        sessions = chains.size - (if (chains.containsKey(0)) 1 else 0)
        save()
    }

    private fun save() {
        prefs.edit()
            .putBoolean("eqOn", eqOn)
            .putString("gains", gains.joinToString(","))
            .putFloat("bass", bass).putFloat("treble", treble)
            .putString("preset", preset)
            .putBoolean("bb", bassBoostOn).putBoolean("sp", spatialOn).putBoolean("ld", loudOn)
            .apply()
    }

    fun setAnc(mode: Int, micGranted: Boolean) {
        ambient.stop()
        anc = mode
        when (mode) {
            0 -> {
                trySetParams("noise_cancellation=on;anc=on;anc_enable=1")
                ancNote = "Orden de cancelación enviada. El efecto real depende del chip de tus audífonos; si no lo soportan, no habrá cambio."
            }
            1 -> {
                trySetParams("noise_cancellation=off;anc=off;anc_enable=0")
                if (micGranted) {
                    ambient.start()
                    ancNote = "Sonido ambiente activo con el micrófono del teléfono. Úsalo con audífonos puestos."
                } else {
                    anc = 2
                    ancNote = "Falta el permiso de micrófono para el modo ambiente."
                }
            }
            else -> {
                trySetParams("noise_cancellation=off;anc=off;anc_enable=0")
                ancNote = ""
            }
        }
    }

    private fun trySetParams(p: String) { try { am.setParameters(p) } catch (_: Throwable) {} }

    fun readVolume() {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        volume = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    fun setVolume(frac: Float) {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val v = (frac.coerceIn(0f, 1f) * max).toInt()
        try { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0) } catch (_: Throwable) {}
        volume = if (max > 0) v.toFloat() / max else 0f
    }
}

/** Paso del micrófono hacia los audífonos (sonido ambiente / transparencia). */
private class Ambient {
    @Volatile private var running = false
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        running = true
        thread = Thread {
            var rec: AudioRecord? = null
            var trk: AudioTrack? = null
            try {
                val sr = 44100
                val minIn = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val minOut = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, minIn * 2)
                val b = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(minOut)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                if (Build.VERSION.SDK_INT >= 26) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                trk = b.build()
                val buf = ShortArray(minIn / 2)
                rec.startRecording()
                trk.play()
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) {
                        for (i in 0 until n) {
                            val v = (buf[i] * 1.6f).toInt().coerceIn(-32768, 32767)
                            buf[i] = v.toShort()
                        }
                        trk.write(buf, 0, n)
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try { rec?.stop() } catch (_: Throwable) {}
                try { rec?.release() } catch (_: Throwable) {}
                try { trk?.stop() } catch (_: Throwable) {}
                try { trk?.release() } catch (_: Throwable) {}
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() { running = false; thread = null }
}
