package com.glassbuds.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.glassbuds.app.ui.DiagScreen
import com.glassbuds.app.ui.EqScreen
import com.glassbuds.app.ui.GlassBackground
import com.glassbuds.app.ui.GlassTheme
import com.glassbuds.app.ui.HomeScreen
import com.glassbuds.app.ui.NavBar
import com.glassbuds.app.ui.SoundScreen

class MainActivity : ComponentActivity() {
    private val vm: GlassVM by viewModels()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            vm.bt.refresh()
            startKeepAlive()
        }

    private fun needed(): Array<String> {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_CONNECT
            l += Manifest.permission.BLUETOOTH_SCAN
        } else {
            l += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        l += Manifest.permission.RECORD_AUDIO
        return l.toTypedArray()
    }

    private fun missing(): Array<String> = needed().filter {
        ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
    }.toTypedArray()

    private fun startKeepAlive() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        } catch (_: Throwable) {
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        vm.askPerms = {
            val m = missing()
            if (m.isNotEmpty()) permLauncher.launch(m)
        }
        val m = missing()
        if (m.isNotEmpty()) permLauncher.launch(m) else startKeepAlive()
        setContent {
            GlassTheme {
                GlassBackground {
                    Box(
                        Modifier
                            .align(Alignment.TopCenter)
                            .widthIn(max = 600.dp)
                            .fillMaxSize()
                            .statusBarsPadding()
                    ) {
                        when (vm.tab) {
                            0 -> HomeScreen(vm)
                            1 -> EqScreen(vm)
                            2 -> SoundScreen(vm)
                            else -> DiagScreen(vm)
                        }
                    }
                    NavBar(
                        vm,
                        Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp)
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.bt.refresh()
        vm.fx.readVolume()
    }
}
